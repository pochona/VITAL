﻿Namespace VITAL

    ''' <summary>
    ''' Adopter : Associations etre propriétaire et animal.
    ''' </summary>
	Partial Public Class Adopter

    End Class

End Namespace
