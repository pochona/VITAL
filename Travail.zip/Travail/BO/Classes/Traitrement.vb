﻿Namespace VITAL

    ''' <summary>
    ''' Traitrement.
    ''' </summary>
	Partial Public Class Traitrement

    End Class

End Namespace
