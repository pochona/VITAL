﻿Namespace VITAL

    ''' <summary>
    ''' Contrat d'assurance.
    ''' </summary>
	Partial Public Class Contrat

    End Class

End Namespace
