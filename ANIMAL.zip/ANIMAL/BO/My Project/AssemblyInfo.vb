﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

'Version de l'application en cours
<Assembly: AssemblyVersion("1.0.0.*")>
'Identification de l'application
<Assembly: AssemblyTitle("VITAL.BO")>
<Assembly: AssemblyDescription("VITAL Business Objects")>
'Identification dans le schema COM
<Assembly: AssemblyProduct("VITAL.BO")>
'Autres informations
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyCopyright("Copyright © Désirade 2017")>
<Assembly: AssemblyTrademark("")>
<Assembly: CLSCompliant(True)>
<Assembly: ComVisible(False)>

'Le GUID suivant est pour l'ID de la typelib si ce projet est exposé à COM
<Assembly: Guid("540C4AD1-6DFC-4074-808A-773276001DFC")>
