﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

'Version de l'application en cours
<Assembly: AssemblyVersion("1.0.0.*")>
'Identification de l'application
<Assembly: AssemblyTitle("VITAL")>
<Assembly: AssemblyDescription("VITAL - VITAL")>
'Identification dans le schema COM
<Assembly: AssemblyProduct("VITAL")>
'Autres informations
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyCopyright("Copyright © Désirade 2017")>
<Assembly: AssemblyTrademark("")>
<Assembly: CLSCompliant(True)>
<Assembly: ComVisible(False)>

'Le GUID suivant est pour l'ID de la typelib si ce projet est exposé à COM
<Assembly: Guid("E2D8468F-4CB0-4FAE-BAC0-9EFCDEECF80B")>
