﻿Namespace VITAL

    ''' <summary>
    ''' Liste des médicaments compris dans un traitement.
    ''' </summary>
	Partial Public Class Traitement_medicament

    End Class

End Namespace
