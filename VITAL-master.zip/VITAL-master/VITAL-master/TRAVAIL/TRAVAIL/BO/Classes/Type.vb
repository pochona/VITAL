﻿Namespace VITAL

    ''' <summary>
    ''' Typede l'animal.
    ''' </summary>
	Partial Public Class Type

    End Class

End Namespace
