﻿Namespace VITAL

    ''' <summary>
    ''' Veterinaire.
    ''' </summary>
	Partial Public Class Veterinaire

    End Class

End Namespace

