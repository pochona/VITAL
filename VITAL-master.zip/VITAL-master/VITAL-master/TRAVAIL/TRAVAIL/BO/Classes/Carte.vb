﻿Namespace VITAL

    ''' <summary>
    ''' Carte vitale.
    ''' </summary>
	Partial Public Class Carte

    End Class

End Namespace
