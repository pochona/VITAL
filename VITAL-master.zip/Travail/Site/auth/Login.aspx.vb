﻿Public Class PageWinCnx
    Inherits CwPageConnectWindows

End Class