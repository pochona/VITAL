﻿Namespace VITAL

    ''' <summary>
    ''' Consultation vétérinaire d'un animal.
    ''' </summary>
	Partial Public Class Consultation

    End Class

End Namespace
