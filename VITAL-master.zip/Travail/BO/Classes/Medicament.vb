﻿Namespace VITAL

    ''' <summary>
    ''' Medicament.
    ''' </summary>
	Partial Public Class Medicament

    End Class

End Namespace
