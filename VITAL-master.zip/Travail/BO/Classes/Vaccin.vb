﻿Namespace VITAL

    ''' <summary>
    ''' Vaccin.
    ''' </summary>
	Partial Public Class Vaccin

    End Class

End Namespace
