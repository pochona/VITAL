﻿Namespace VITAL

    ''' <summary>
    ''' Position de l'animal.
    ''' </summary>
	Partial Public Class Position

    End Class

End Namespace
