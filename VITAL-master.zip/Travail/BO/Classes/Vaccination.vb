﻿Namespace VITAL

    ''' <summary>
    ''' Vaccination d'un animal.
    ''' </summary>
	Partial Public Class Vaccination

    End Class

End Namespace
