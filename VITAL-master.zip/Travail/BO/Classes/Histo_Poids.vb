﻿Namespace VITAL

    ''' <summary>
    ''' Historique du poids de l'animal.
    ''' </summary>
	Partial Public Class Histo_Poids

    End Class

End Namespace
