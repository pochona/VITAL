﻿Namespace VITAL

    ''' <summary>
    ''' Historique de la taille de l'animal.
    ''' </summary>
	Partial Public Class Histo_Taille

    End Class

End Namespace
