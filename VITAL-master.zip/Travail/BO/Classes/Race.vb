﻿Namespace VITAL

    ''' <summary>
    ''' Race de l'animal.
    ''' </summary>
	Partial Public Class Race

    End Class

End Namespace
