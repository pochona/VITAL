﻿Namespace VITAL

    ''' <summary>
    ''' Assurance.
    ''' </summary>
	Partial Public Class Assurance

    End Class

End Namespace
