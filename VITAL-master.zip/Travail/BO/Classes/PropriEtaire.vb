﻿Namespace VITAL

    ''' <summary>
    ''' Propriétaire.
    ''' </summary>
	Partial Public Class PropriEtaire

    End Class

End Namespace
